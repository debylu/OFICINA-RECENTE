<?php
require_once 'head.php';
 require_once 'menu.php';
?>







<?php
             require_once 'footer.php';
             ?>