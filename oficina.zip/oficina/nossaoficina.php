<?php
require_once 'head.php';
 require_once 'menu.php';
?>

<div class="container-fluid">
    <div class="row text-center">
        <div class="col-md-12">
        <h1> Nossa história</h1>
</div>
</div>
    <div class="row servicos">
    <div class="col-md-6"><img src="imagens/carro1.webp" alt="imagemquemsomos">
</div>
    <div class="col-md-6 text-center">
                   
                          <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laudantium blanditiis, nemo autem reiciendis 
                        necessitatibus temporibus odit incidunt recusandae
                           mollitia dolore c Lorem ipsum dolor sit amet consectetur adipisicing elit.
                            Quaerat voluptate ad neque, sapiente autem nihil et in? Nemo non 
                           quod alias dolor fugiat libero aperiam, fuga quo necessitatibus illum? Quod.</p> 
                        </div>
     
             </div>

    
  
</div>

<div class="container-fluid">
    <div class="col-md-12 text-center">
        <h1>Nossos valores</h1>
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Repudiandae 
            quae beatae voluptas iusto nostrum doloribus, animi nam dolorum excepturi distinctio fugit 
             perspiciatis illum rerum deserunt optio voluptate eaque minima!
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod, natus tenetur. Reprehenderit, 
            beatae repudiandae. Tempora, nulla explicabo
             id saepe neque a ipsa eum itaque nesciunt totam facere dicta delectus ab.</p></div></div>

             <?php
             require_once 'footer.php';
             ?>